﻿------------------------
--   Installation :   --
------------------------

Step 1 :
	déziper le dossier reçue par email dans le repertoir local du server
Step 3 :
	Modifier le fichier MySiiChallenge/controleur/Connection.php en ajouter
	ses paramétre d'authentification préalablement demander sur la page https://apps.twitter.com/

	les lignes a renseigné sont L.33 a L.36
Step 2 :
acceder a : http://localhost/MySiiChallenge/


-------------------------
--   Mode d'emploi :   --
-------------------------

-Pour rechercher un compte twitter : 
	utiliser la barre de recherche et cliquer sur OK
	si le compte twitter recherché existe il s'affichera a coté des deux autres.

-Pour charger plus de tweet : 
	cliquer sur le bouton "LOAD MORE"

-Pour acceder a la page du compte twitter :
	cliquer sur le nom du compte ou sur la photo de profil

-Pour accer au contenue du tweet :
	cliquer sur le directement sur le tweet (le bloc du tweet)


